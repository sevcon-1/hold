/* NEW RESTRICTED VERSION UPDATE */
<%
   if (odiRef.getOption("DECODE_RESTRICTED_UPDATES").equals("1"))
       targetColsMappedFromSource = odiRef.getColList("", "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND (NOT TRG) AND (NOT UD2)) AND REW)");
       targetColsMappedOnTarget = odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND (NOT UD2) AND REW)"), "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)");
       decodeCols = odiRef.getColList("", "decode(s.RESTRICTED_UPDATE,1,t.[COL_NAME],s.[COL_NAME])", ",\n\t", "", "((UD2 AND UPD AND (NOT UK) AND (NOT TRG)) AND REW)");
   else 
       targetColsMappedFromSource = odiRef.getColList("", "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)");
       targetColsMappedOnTarget = odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)"), "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)");
   
   if (targetColsMappedFromSource.trim().length() == 0 &&
       targetColsMappedOnTarget.trim().length() == 0)
       throw new OdiKMException( "More target column mappings needed: at least one target column, which is not part of the update key, must have a mapping expression assigned." );
%>
update  <%=odiRef.getTable("L", "TARG_NAME", "A")%> T
set (
    <%=targetColsMappedFromSource%>
    <%=targetColsMappedOnTarget%>  
    <%decodeCols%>
    <%if ( odiRef.getOption("UPDATE_ODI_COLUMNS").equals("1") ) { %> 
        , ODI_ROW_IND
        , ODI_UPDATE_PROCESS
        , ODI_UPDATE_TS
    <% } %>
     )
     =
        (
        select
        <%if (odiRef.getOption("DECODE_RESTRICTED_UPDATES").equals("1")) {%>
                <%=odiRef.getColList("", "S.[COL_NAME]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND (NOT TRG) AND (NOT UD2)) AND REW)")%>
                <%=odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG) AND (NOT UD2)) AND REW)"), "[EXPRESSION]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)")%>
                <%=odiRef.getColList("", "decode(s.RESTRICTED_UPDATE,1,t.[COL_NAME],s.[COL_NAME])", ",\n\t", "", "((UD2 AND UPD AND (NOT UK) AND (NOT TRG)) AND REW)")%>
                        <% } else {%>
            <%=odiRef.getColList("", "S.[COL_NAME]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)")%>
            <%=odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)"), "[EXPRESSION]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)")%>
                        <% } %>
                        <%if ( odiRef.getOption("UPDATE_ODI_COLUMNS").equals("1") ) { %>
                        , 'U' ODI_ROW_IND
                        , '<%=odiRef.getSession("SESS_NAME")%>' ODI_UPDATE_PROCESS
                        , systimestamp ODI_UPDATE_TS
                        <% } %>
        from    <%=odiRef.getTable("L", "INT_NAME", "W")%> S
        where   IND_UPDATE = 'U'
        and <%=odiRef.getColList("", "T.[COL_NAME]  =S.[COL_NAME]", "\n\t\tand\t", "", "UK")%>
             )
where   (<%=odiRef.getColList("", "[COL_NAME]", ", ", "", "UK")%>)
    in  (
        select  <%=odiRef.getColList("", "[COL_NAME]", ",\n\t\t\t", "", "UK")%>
        from    <%=odiRef.getTable("L", "INT_NAME", "W")%>
        where   IND_UPDATE = 'U'
        )
        
        
        
/* OLD VERSION */
<%
   targetColsMappedFromSource = odiRef.getColList("", "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)");
   targetColsMappedOnTarget = odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)"), "T.[COL_NAME]", ",\n\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)");
   if (targetColsMappedFromSource.trim().length() == 0 &&
       targetColsMappedOnTarget.trim().length() == 0)
       throw new OdiKMException( "More target column mappings needed: at least one target column, which is not part of the update key, must have a mapping expression assigned." );
%>
update  <%=odiRef.getTable("L", "TARG_NAME", "A")%> T
set (
    <%=targetColsMappedFromSource%>
    <%=targetColsMappedOnTarget%>   
    <%if ( odiRef.getOption("UPDATE_ODI_COLUMNS").equals("1") ) { %> 
        , ODI_ROW_IND
        , ODI_UPDATE_PROCESS
        , ODI_UPDATE_TS
    <% } %>
     )
     =
        (
        select
        <%if (odiRef.getOption("DECODE_RESTRICTED_UPDATES").equals("1")) {%>
                        <%=odiRef.getColList("", "decode(s.RESTRICTED_UPDATE,1,t.[COL_NAME],s.[COL_NAME])", ",\n\t", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)")%>
                        <% } else {%>
            <%=odiRef.getColList("", "S.[COL_NAME]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)")%>
            <%=odiRef.getColList(odiRef.getColList(",", " ", "", "", "((UPD AND (NOT UK) AND (NOT TRG)) AND REW)"), "[EXPRESSION]", ",\n\t\t\t", "", "((UPD AND (NOT UK) AND TRG) AND REW)")%>
                        <% } %>
                        <%if ( odiRef.getOption("UPDATE_ODI_COLUMNS").equals("1") ) { %>
                        , 'U' ODI_ROW_IND
                        , '<%=odiRef.getSession("SESS_NAME")%>' ODI_UPDATE_PROCESS
                        , systimestamp ODI_UPDATE_TS
                        <% } %>
        from    <%=odiRef.getTable("L", "INT_NAME", "W")%> S
        where   IND_UPDATE = 'U'
        and <%=odiRef.getColList("", "T.[COL_NAME]  =S.[COL_NAME]", "\n\t\tand\t", "", "UK")%>
             )
where   (<%=odiRef.getColList("", "[COL_NAME]", ", ", "", "UK")%>)
    in  (
        select  <%=odiRef.getColList("", "[COL_NAME]", ",\n\t\t\t", "", "UK")%>
        from    <%=odiRef.getTable("L", "INT_NAME", "W")%>
        where   IND_UPDATE = 'U'
        )
        
                