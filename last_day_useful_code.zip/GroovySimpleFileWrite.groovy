//Created by DI Studio

File file = new File("Z:\\SBCI\\DEV\\tmp\\test.txt")
file.write "C1\tC2\tC3\tC4\r\n"

1.upto(10) {
  file << "Line: " + it + "\tV1" + it + "\tV2" + it + "\tV3" + it + "\r\n"
  //println file.text
  //file.text = "Line: " + it + "\tL2\tL3\tL4\r\n"
  //println "Line: " + it + "\tL2\tL3\tL4\r\n"
}