import java.util.List;
import oracle.odi.core.OdiInstance;
import oracle.odi.core.config.OdiInstanceConfig;
import oracle.odi.core.config.MasterRepositoryDbInfo;
import oracle.odi.core.config.WorkRepositoryDbInfo;
import oracle.odi.core.security.Authentication;
import oracle.odi.core.config.PoolingAttributes;

import oracle.odi.domain.project.OdiProject;
import oracle.odi.domain.project.finder.IOdiProjectFinder;
import oracle.odi.domain.project.finder.IOdiFolderFinder;
import oracle.odi.domain.model.finder.IOdiDataStoreFinder;
import oracle.odi.domain.topology.finder.IOdiContextFinder;
import oracle.odi.domain.project.OdiFolder;
import oracle.odi.domain.project.OdiInterface;
import oracle.odi.domain.project.interfaces.DataSet;
import oracle.odi.domain.model.OdiDataStore;
import oracle.odi.domain.topology.OdiContext;

import oracle.odi.core.persistence.transaction.ITransactionStatus;
import oracle.odi.core.persistence.transaction.ITransactionManager;
import oracle.odi.core.persistence.transaction.ITransactionDefinition;
import oracle.odi.core.persistence.transaction.support.DefaultTransactionDefinition;

import oracle.odi.domain.mapping.finder.IMappingFinder;
import oracle.odi.domain.mapping.Mapping;
import oracle.odi.domain.mapping.MapComponent;
import oracle.odi.domain.mapping.MapAttribute;
import oracle.odi.domain.mapping.MapConnectorPoint;
import oracle.odi.domain.mapping.component.DatastoreComponent;
import oracle.odi.domain.mapping.component.FileComponent;
import oracle.odi.domain.mapping.component.JoinComponent;
import oracle.odi.domain.mapping.component.FilterComponent;
import oracle.odi.domain.mapping.component.LookupComponent;
import oracle.odi.domain.mapping.component.SplitterComponent;
import oracle.odi.domain.mapping.component.SetComponent;
import oracle.odi.domain.mapping.component.Dataset;
import oracle.odi.core.persistence.transaction.support.DefaultTransactionDefinition;


import java.util.Collection;
import java.io.*;

/*
  Mapping Builder

  Execute using:
    java -classpath <cp> 
    OdiMappingBuilder <url> <driver> <schema> <pwd> <workrep> <odiuser> <odiuserpwd> <project> <folder> <control_file>

  the control file provided in the standard input stream needs to be a tab delimited file with the following structure

source	<model>	<datastore>	<alias>
..
target	<model	<datastore>
target_load	<model	<datastore>	<split_condition>|else
mapping	<column>	<expression>
... 
join	<join_expression>	<join_alias>
...
filter	<filter_expression>	<source_alias>	<filter_alias>
...
lookup	<model>	<datastore>	<driver_alias>	<lookup_expression>	<lookup_alias>
...


for example....

source	SCOTT	EMP	EMP
source	SCOTT	DEPT	DEPT
target	STG_MODEL_CASE	STG_DEPT
mapping	DNAME	UPPER(DEPT.DNAME)
mapping	DEPTNO	ABS(EMP.EMPNO)
join	EMP.DEPTNO = DEPT.DEPTNO	AJOIN
filter	EMP.SAL > 1	EMP	AFILTER
lookup	SCOTT	BONUS	EMP	BONUS.ENAME = EMP.ENAME	ALOOKUP

*/

public class OdiMappingBuilder
{
enum MatchTypes {EQUALS,SRCENDSWITH, TGTENDSWITH, SRCSTARTSWITH, TGTSTARTSWITH};
enum MatchCaseTypes {MATCH,IGNORECASE};

  public static void createTgtExpression(DatastoreComponent tgtDSC, OdiDataStore tgtTable, String propertyName, String expressionText) throws Exception { 
  DatastoreComponent.findAttributeForColumn(tgtDSC,tgtTable.getColumn(propertyName)).setExpressionText(expressionText);
}

  public static void createTgtExpressions(MapComponent component, MapConnectorPoint conPoint, MatchTypes matchType, MatchCaseTypes matchCaseType) throws Exception { 
  List<MapAttribute> atts = null;
  if (conPoint != null)   atts = conPoint.getUpstreamInScopeAttributes();
  else atts = component.getUpstreamLeafAttributes(component);
  List<MapAttribute> tatts = component.getAttributes();

  for (MapAttribute tgt_attr : tatts) {
    String attr_str = tgt_attr.getName();
    if (matchCaseType == MatchCaseTypes.IGNORECASE) {
      attr_str = attr_str.toLowerCase();
    }
    MapAttribute sourceCol = null;
    for (MapAttribute src_attr :  atts) {
      String src_attr_str = src_attr.getName();
      if (matchCaseType == MatchCaseTypes.IGNORECASE) {
       src_attr_str = src_attr_str.toLowerCase();
      }
      if ( (matchType == MatchTypes.SRCENDSWITH && src_attr_str.endsWith( attr_str )) ||
           (matchType == MatchTypes.SRCSTARTSWITH && src_attr_str.startsWith( attr_str )) ||
           (matchType == MatchTypes.TGTSTARTSWITH && attr_str.startsWith( src_attr_str )) ||
           (matchType == MatchTypes.TGTENDSWITH && attr_str.endsWith( src_attr_str )) ||
           (matchType == MatchTypes.EQUALS && attr_str.equals( src_attr_str )) ) {
       sourceCol = src_attr;
       break;
      }
    }
    if (sourceCol != null && conPoint != null)  tgt_attr.setExpression( conPoint, sourceCol, null );
    else if (sourceCol != null)  tgt_attr.setExpression( sourceCol );
  }
}

  public static void main(String[] args) throws Exception
  {
    mainf(args);
  }
  public static void mainf(String[] args) throws Exception
  {
    if (args.length != 11) {System.err.println("Error usage: OdiMappingBuilder <url> <driver> <schama> <pwd> <workrep> <odiuser> <odipwd> <project> <folder> <iname> <control_file>"); return; }
    String url = args[0];
    String driver = args[1];
    String schema = args[2];
    String schemapwd = args[3];
    String workrep = args[4];
    String odiuser= args[5];
    String odiuserpwd = args[6];
    String project = args[7];
    String folder = args[8];
    String iname = args[9];
    String inFilename = args[10];
    try {
      MasterRepositoryDbInfo masterInfo = new     MasterRepositoryDbInfo(url, driver, schema, schemapwd.toCharArray(), new PoolingAttributes());
      WorkRepositoryDbInfo workInfo = new WorkRepositoryDbInfo(workrep, new PoolingAttributes());

      OdiInstance odiInstance = OdiInstance.createInstance(new OdiInstanceConfig(masterInfo, workInfo));
      Authentication auth = odiInstance.getSecurityManager().createAuthentication(odiuser, odiuserpwd.toCharArray());
      odiInstance.getSecurityManager().setCurrentThreadAuthentication(auth);
      mainm(odiInstance, project,  folder,  iname,  new FileInputStream(inFilename));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void build(OdiInstance odiInstance, String project, String folder, String iname, String ifilename) throws Exception
  {
    try {
      mainm(odiInstance, project,  folder,  iname,  new FileInputStream(ifilename));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  public static void mainm(OdiInstance odiInstance, String project, String folder, String iname, InputStream inps) throws Exception
  {
    try {
      ITransactionDefinition txnDef = new DefaultTransactionDefinition();
      ITransactionManager tm = odiInstance.getTransactionManager();
      ITransactionStatus txnStatus = tm.getTransaction(txnDef);

      Collection<OdiFolder> odiFolders = ((IOdiFolderFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiFolder.class)).findByName(folder,project);
      if (odiFolders.size() == 0) {System.err.println("Error: cannot find folder "+folder+" in project "+project); return; }
      OdiFolder odiFolder = (OdiFolder) (odiFolders.toArray()[0]);

      OdiContext context = ((IOdiContextFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiContext.class)).findDefaultContext();

      BufferedReader in = new BufferedReader(new InputStreamReader(inps));

      buildMapping(odiInstance, context, in, iname, odiFolder);

      tm.commit(txnStatus);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void buildMapping(OdiInstance odiInstance, OdiContext context,BufferedReader in, String iname,OdiFolder odiFolder) {
    String s;
    try {
      Mapping map = new Mapping(iname, odiFolder); 
      odiInstance.getTransactionalEntityManager().persist(map);

      Dataset dataSet = (Dataset) map.createComponent("DATASET","DEFAULTDATASET");
      OdiDataStore targetDatastore = null;
      SplitterComponent splitc = null;
      int splitcnt = 0;
      DatastoreComponent targetDatastoreC = null;

      while ((s = in.readLine()) != null) {
        if (s.length() == 0) continue;
        try {
          String toks[] = s.split("\t");
          String cmd = toks[0];

          if (cmd.compareTo("source") == 0) {
            String srcmodel = toks[1];
            String srctab = toks[2];
            String srcalias = toks[3];
            OdiDataStore odiDatastore1 = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(srctab, srcmodel);
            DatastoreComponent dsc = (DatastoreComponent) dataSet.addSource(odiDatastore1, false);
            dsc.setName(srcalias);
          }
          if (cmd.compareTo("source_file") == 0) {
            String srcmodel = toks[1];
            String srctab = toks[2];
            String srcalias = toks[3];
            OdiDataStore odiDatastore1 = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(srctab, srcmodel);
            FileComponent dsc = (FileComponent) dataSet.createComponent(FileComponent.COMPONENT_TYPE_NAME,odiDatastore1);
            dsc.setName(srcalias);
          }

          if (cmd.compareTo("target") == 0) {
            String tgtmodel = toks[1];
            String tgttab = toks[2];

            targetDatastore = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(tgttab, tgtmodel);
            targetDatastoreC  = (DatastoreComponent) map.createComponent("DATASTORE",targetDatastore, false);
            dataSet.connectTo(targetDatastoreC);
          }
          if (cmd.compareTo("targetinc") == 0) {
            String tgtmodel = toks[1];
            String tgttab = toks[2];

            targetDatastore = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(tgttab, tgtmodel);
            targetDatastoreC  = (DatastoreComponent) map.createComponent("DATASTORE",targetDatastore, false);
            dataSet.connectTo(targetDatastoreC);
            targetDatastoreC.setIntegrationType(DatastoreComponent.INTEGRATION_TYPE_UPDATE);
          }

          if (cmd.compareTo("target_load") == 0) {
            String tgtmodel = toks[1];
            String tgttab = toks[2];
            String splitcond = toks[3];
            if (splitc == null) splitc = new SplitterComponent(map, "SPLIT_DATA");

            targetDatastore = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(tgttab, tgtmodel);
            targetDatastoreC  = (DatastoreComponent) map.createComponent("DATASTORE",targetDatastore, false);
            if (splitcnt == 0) dataSet.connectTo(splitc);
            splitc.getOutputConnectorPoint(splitcnt++).connectTo(targetDatastoreC);
            if (splitcond.equals("else")) 
              splitc.setRemainder(splitc.getOutputConnectorPoint(splitcnt-1), true);
            else
              splitc.setSplitterCondition(splitc.getOutputConnectorPoint(splitcnt-1), splitcond);
          }

          if (cmd.compareTo("join") == 0) {
            String join_exp = toks[1];
            String jalias = toks[2];
            JoinComponent jnc = dataSet.addJoin(join_exp);
            jnc.setName(jalias);
          }

          if (cmd.compareTo("filter") == 0) {
            String filter_exp = toks[1];
            String comp = toks[2];
            String falias = toks[3];
            FilterComponent filterC  = (FilterComponent) dataSet.createComponent("FILTER","FILTER_DATA");
            DatastoreComponent dsc  = (DatastoreComponent) dataSet.findComponent(comp);
            filterC.setFilterCondition(filter_exp);
            filterC.setName(falias);
            dsc.connectTo(filterC);
          }

          if (cmd.compareTo("lookup") == 0) {
            String src_model = toks[1];
            String src_tab = toks[2];
            String alias = toks[3];
            String lookup_exp = toks[4];
            String lalias = toks[5];
            OdiDataStore lkpDatastore = ((IOdiDataStoreFinder)odiInstance.getTransactionalEntityManager().getFinder(OdiDataStore.class)).findByName(src_tab, src_model);
            DatastoreComponent driver  = (DatastoreComponent) dataSet.findComponent(alias);
            LookupComponent lkc = dataSet.addLookup(driver, lkpDatastore, lookup_exp);
            lkc.setName(lalias);
          }

          if (cmd.compareTo("mapping") == 0) {
            String col = toks[1];
            String exp = toks[2];
            createTgtExpression(targetDatastoreC, targetDatastore , col, exp);
          }
          if (cmd.compareTo(">mapping") == 0) {
            String matchType = toks[1];
            String matchCaseType = toks[2];
            createTgtExpressions(targetDatastoreC.getPersistentComponent(), (MapConnectorPoint)null, MatchTypes.valueOf(matchType), MatchCaseTypes.valueOf(matchCaseType));
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
     }
      try {
        odiInstance.getTransactionalEntityManager().persist(map);
      } catch (Exception e) {
        e.printStackTrace();
      }


    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
