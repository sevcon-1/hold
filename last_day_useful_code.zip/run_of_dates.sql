with v as (
    select level lvl, to_date('20160101', 'yyyymmdd')+(level-1) d from dual
    where 1=1 
    --and level != 10
    and mod(level, 14) > 0
    connect by level <= 31
),
w as (
select lvl, d, lag(d,1,d) over (order by d) prev_day, (d- (lag(d,1,d) over (order by d))) diff from v
)
select decode(diff, 1, null, 'MISSED DAY') as msg, w.* from w
;