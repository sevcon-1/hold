declare
CHILD_FOUND exception;
pragma exception_init(CHILD_FOUND,-2292);
numrows number;
zero_total number := 0;
runagain boolean := FALSE;
begin

    for i in (select owner||'.'||table_name t from all_tables where 1=1
                 and table_name in
                                  (
                                   'FOU_ACCOUNTS','FOU_AMB_COUPON_RATIOS','FOU_CASH_FLOW_TRANSACTIONS','FOU_CASH_FLOW_TYPES','FOU_CG_REF_CODES'
                                  ,'FOU_CITIES','FOU_COUNTRIES'
                                  ,'FOU_CURRENCIES','FOU_FREQUENCIES','FOU_INTEREST_CALCULATIONS','FOU_NDP_LATEST_BALANCE','FOU_ORGANISATIONS'
                                  ,'FOU_REF_CODES','FOU_SPRINT_MODULES,FOU_STATES'
                                  )

    ) loop
      begin
        numrows := -1;

         begin
             dbms_output.put_line('deleting '||i.t);
             execute immediate 'delete '||i.t||' purge';
        exception
            when CHILD_FOUND then
                runagain:=TRUE;
        end;
      end;

    end loop;
    --dbms_output.put_line('Number of empty tables: '||zero_total);
    
    if (runagain) then
        dbms_output.put_line('Children existed. Run Again');
    end if;

end ;

