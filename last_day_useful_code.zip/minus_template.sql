select 	
<COLS>
  count(src1) bkp_cnt,
  count(src2) curr_cnt
from (
      select 
<COLS>
      1 src1,
      to_number(null) src2
      from <TABLE>
       where 1=1
      union all
      select 
      <COLS>
      to_number(null) src1,
      2 src2
      from <TABLE>
       where 1=1
      ) f
where 1=1
group by     
<COLS>
having count(src1) != count(src2) 
--having count(src1) > count(src2) -- more in backup than fact
--having count(src1) != 0 and  count(src2) = 0
--order by 
;
--SELECT * FROM NDMIS_DM.DIM_ORGANISATIONS;