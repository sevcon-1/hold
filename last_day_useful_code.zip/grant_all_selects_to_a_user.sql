----------------------------------------------------------------
-- Grant Select on objects owned by NDMIS users to ODI_OPERATOR
----------------------------------------------------------------
BEGIN
    for i in (    select  'grant select on '||owner||'.'||table_name||' to odi_operator'  g from all_tables where owner in 
    ( 'ODI_WORK', 'NDMIS_DM', 'NDMIS_FOUNDATION', 'NDMIS_STAGE', 'NDMIS_LOAD', 'NDMIS_AUDIT'))
    loop
        execute immediate i.g;
    end loop;
end;    
