declare
CHILD_FOUND exception;
pragma exception_init(CHILD_FOUND,-2292);
numrows number;
zero_total number := 0;
runagain boolean := FALSE;
begin

    for i in (select owner||'.'||table_name t from all_tables where table_name like 'FOU%' and owner ='NDMIS_FOUNDATION') loop
      begin
        numrows := -1;

/* COUNT LINES */        
        execute immediate 'select count(1) from '||i.t into numrows;
        if (nvl(numrows,0) != 0 ) then 
            dbms_output.put_line('Count for '||i.t||' is '||numrows);
        end if;
/* END COUNT LINES */        

    if (numrows=0) then
          raise no_data_found;
        end if;
      exception
        when no_data_found then 
        dbms_output.put_line('Zero count for: '||i.t); 
        zero_total:=zero_total+1;
      end;
    end loop;
    dbms_output.put_line('Number of empty tables: '||zero_total);
end ;  

