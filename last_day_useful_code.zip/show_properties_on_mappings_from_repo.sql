select comp.name map_name, a.name, p.name as flag, p.prop_value from snp_map_prop p, snp_map_attr a, snp_map_ref r, snp_map_cp cp, snp_map_comp comp
where 1=1
and cp.i_owner_map_comp = comp.i_map_comp
and a.i_owner_map_cp = cp.i_map_cp
and a.i_map_ref = r.i_map_ref
and p.i_map_attr = a.i_map_attr
and p.name like 'UD\_%' escape '\';

select * from snp_map_prop p where p.name = 'UD_2';